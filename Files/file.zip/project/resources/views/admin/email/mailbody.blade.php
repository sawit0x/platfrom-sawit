@php
    echo $email_body;
@endphp 
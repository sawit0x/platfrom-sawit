<?php

namespace App\Http\Controllers\Deposit;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CoinpaymentController extends Controller
{
    //
}
